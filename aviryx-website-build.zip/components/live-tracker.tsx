"use client"

import { useState, useEffect } from "react"
import { InfoCard } from "./info-card"

export function LiveTracker() {
  const [price, setPrice] = useState<string | null>(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    // Simulated price display - in production, connect to actual price API
    const timer = setTimeout(() => {
      setPrice("$0.00000042")
      setLoading(false)
    }, 1500)

    return () => clearTimeout(timer)
  }, [])

  return (
    <InfoCard title="Live Tracker">
      <div className="text-lg">
        {loading ? (
          <span className="text-muted-foreground animate-pulse">
            Loading price...
          </span>
        ) : (
          <div className="flex flex-col gap-2">
            <div className="flex items-center gap-3">
              <span className="text-muted-foreground">$AVX Price:</span>
              <span className="text-secondary font-bold text-xl">{price}</span>
            </div>
            <p className="text-sm text-muted-foreground mt-2">
              Connect to pump.fun for real-time pricing
            </p>
          </div>
        )}
      </div>
    </InfoCard>
  )
}
