"use client"

import Link from "next/link"

export function HeroSection() {
  return (
    <header className="relative text-center px-5 pt-24 pb-10 md:pt-32 md:pb-16">
      <div className="mb-6">
        <img
          src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/AVX-rupm9N4pM384VV5xsuKDJ7rfnQa7Up.png"
          alt="Aviryx - Skull-crowned Spirit"
          className="w-32 h-32 md:w-48 md:h-48 mx-auto rounded-full border-2 border-primary shadow-[0_0_30px_rgba(143,152,255,0.6)]"
        />
      </div>
      <h1 className="font-[family-name:var(--font-creepster)] text-5xl md:text-7xl text-primary drop-shadow-[0_0_20px_rgba(143,152,255,0.8)] mb-3">
        Welcome to the Nest
      </h1>
      <p className="text-muted-foreground text-lg md:text-xl mt-4 max-w-xl mx-auto">
        Enter the world of Aviryx — Skull-crowned Spirit of the Chain
      </p>
      <div className="mt-8">
        <Link
          href="https://pump.fun/coin/8eXaoSuJAJ8fBaWtxxpgVtiHVbqPgMV9JGvrifnHpump"
          target="_blank"
          rel="noopener noreferrer"
          className="inline-block bg-gradient-to-r from-primary to-secondary px-8 py-4 rounded-full text-secondary-foreground font-bold text-lg border-2 border-secondary shadow-[0_0_25px_rgba(120,232,232,0.6),0_0_10px_rgba(143,152,255,0.4)] hover:shadow-[0_0_35px_rgba(120,232,232,0.8)] transition-shadow duration-300"
        >
          BUY $AVX NOW
        </Link>
      </div>
    </header>
  )
}
