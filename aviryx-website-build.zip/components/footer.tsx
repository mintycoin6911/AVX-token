export function Footer() {
  return (
    <footer className="text-center text-muted-foreground py-6 mt-8">
      © {new Date().getFullYear()} Aviryx. All rights reserved.
    </footer>
  )
}
