interface InfoCardProps {
  title: string
  children: React.ReactNode
}

export function InfoCard({ title, children }: InfoCardProps) {
  return (
    <div className="bg-card rounded-xl p-6 shadow-[0_0_25px_rgba(0,0,0,0.6)]">
      <h2 className="text-primary text-xl md:text-2xl font-bold border-b-2 border-primary pb-2 mb-4 drop-shadow-[0_0_10px_rgba(143,152,255,0.5)]">
        {title}
      </h2>
      <div className="text-foreground leading-relaxed">{children}</div>
    </div>
  )
}
